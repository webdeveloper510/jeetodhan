<?php return array('dependencies' => array('wc-blocks-registry', 'wp-element'), 'version' => '785e90b5a161556af725');
