<?php
/**
 * Silence is golden.
 *
 * @package NCSUCP
 */
